package com.example.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FinalProject {

	public static void main(String[] args) {
		SpringApplication.run(FinalProject.class, args);
	}

}
